// // Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// // Case 2 - Named Exports
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return "Checked: " + x;
// }

// Case 3 - Named & Default Exports
export default function square(x) {
    return x * x;
}

export function check(x) {
    return "Checked: " + x;
}