(function () {
    'use strict';

    // // Case 1 - Default Export
    // export default function square(x) {
    //     return x * x;
    // }

    // // Case 2 - Named Exports
    // export function square(x) {
    //     return x * x;
    // }

    // export function check(x) {
    //     return "Checked: " + x;
    // }

    // Case 3 - Named & Default Exports
    function square(x) {
        return x * x;
    }

    function check(x) {
        return "Checked: " + x;
    }

    // Case 1 - Default Import
    console.log("Result: ", square(20));
    console.log("Result: ", check(20));

}());
