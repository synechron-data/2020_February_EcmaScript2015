import '../public/favicon.ico';

// import './1_Modules/usage';

// import './2_Functions/1_FnParameters';
// import './2_Functions/2_RestAndSpread';
// import './2_Functions/3_PureAndImpureFn';
// import './2_Functions/4_FnAsParameters';
// import './2_Functions/5_ArrowFn';
// import './2_Functions/6_IIFE';
import './2_Functions/7_FnCurrying';

