// function add1(x, y) {
//     return x + y;
// }

// const add2 = function (x, y) {
//     return x + y;
// }

// const add3 = (x, y) => {
//     return x + y;
// }

// const add4 = (x, y) => x + y;

// console.log(add1(2, 3));
// console.log(add2(2, 3));
// console.log(add3(2, 3));
// console.log(add4(2, 3));

// -------------------------------------- Use case
var employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Neeraj", city: "Delhi" },
    { id: 3, name: "Pravin", city: "Pune" }
];

// var result = [];

// for (let i = 0; i < employees.length; i++) {
//     if(employees[i].city === "Pune")
//         result.push({...employees[i]});    
// }

// console.log(result);

// -----------------------------

// var result = [];

// function filterLogic(e){
//     return e.city === "Pune"
// }

// for (let i = 0; i < employees.length; i++) {
//     if(filterLogic(employees[i]))
//         result.push({...employees[i]});    
// }

// console.log(result);


// ---------------------------------
// function filterLogic(e) {
//     return e.city === "Pune"
// }

// var result = employees.filter(filterLogic);

// console.log(result);

// ------------------------------------------
// var result = employees.filter(function (e) {
//     return e.city === "Pune"
// });

// console.log(result);

// // ------------------------------------------
// var result = employees.filter((e) => {
//     return e.city === "Pune"
// });

// console.log(result);

// ------------------------------------------
var result = employees.filter(e => e.city === "Pune");
console.log(result);