// // --------------------- Primitive

// var a = 1;

// function modify(data){
//     data = 100;
// }

// console.log(`Before = ${a}`);
// modify(a);
// console.log(`After = ${a}`);

// // --------------------- Complex Type

// var a = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// function modify(data) {
//     data[0] = 100;
// }

// console.log(`Before = ${a}`);
// modify(a);
// console.log(`After = ${a}`);

var a = [10, 20];

// Impure
// function create(dataArr, x) {
//     dataArr[dataArr.length] = x;
//     return dataArr;
// }

// Pure
function create(dataArr, x) {
    var rArr = [...dataArr];
    rArr[dataArr.length] = x;
    return rArr;
}

var newArr1 = create(a, 30);
console.log(`New Array = ${newArr1}`);

var newArr2 = create(a, 40);
console.log(`New Array = ${newArr2}`);