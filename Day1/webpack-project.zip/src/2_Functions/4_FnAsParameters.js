// document.getElementById("b1").addEventListener("click", function (e) {

// })

// $(document).ready(function () {

// });

// setInterval(function () { }, 1000);

// ------------------------------------- 
// // Dev1
// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2
// setInterval(function () {
//     var s = getString();
//     console.log(s);
// }, 2000);

// ------------------------------------- Push
// Dev1
function getString(cb) {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
    setInterval(function () {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// Dev 2
getString(function (s) {
    console.log(s);
});