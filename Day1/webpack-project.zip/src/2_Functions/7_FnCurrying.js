// function greetings(message, name){
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(' km', 1.6, 0, 10));
// console.log(Converter(' km', 1.6, 0, 100));
// console.log(Converter(' km', 1.6, 0, 120));

// console.log(Converter(' INR', 70, 0, 100));
// console.log(Converter(' INR', 70, 0, 500));
// console.log(Converter(' INR', 70, 0, 900));
// console.log(Converter(' INR', 70, 0, 1000));

// -----------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// const mGreet = greetings("Good Morning");
// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

function Converter(toUnit, factor, offset) {
    return (input) => {
        return [((offset + input) * factor).toFixed(2), toUnit].join("");
    }
}

const milesToKm = Converter(' km', 1.6, 0);
const usdToInr = Converter(' INR', 70, 0);

// console.log(milesToKm(10));
// console.log(milesToKm(160));
// console.log(milesToKm(234));

console.log(usdToInr(1000));
console.log(usdToInr(1900));
console.log(usdToInr(200));
console.log(usdToInr(5600));
