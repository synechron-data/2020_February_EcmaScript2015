var dev1;

(function (d) {
    function Test() {
        console.log("Test from Dev 1 Called");
    }

    d.Test = Test;
})(dev1 = dev1 || {});

// var dev2;

// (function (d) {
//     function Test() {
//         console.log("Test from Dev 2 Called");
//     }

//     d.Test = Test;
// })(dev2 = dev2 || {});

// console.log(dev1);
// console.log(dev2);

// dev1.Test();

// dev2.Test();