var calculator = (function () {
    function add(x, y) {
        return x + y;
    }

    function sub(x, y) {
        return x + y;
    }

    function mul(x, y) {
        return x + y;
    }

    return {
        add, sub
    };
})();

console.log(calculator);