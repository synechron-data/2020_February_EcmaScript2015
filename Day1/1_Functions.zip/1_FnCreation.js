// 'use strict'
// // function test() {
// //     var a = 10;
// //     console.log("Inside Fn, a is", a);
// // }

// // test();
// // console.log("Outside Fn, a is", a);

// // Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.
// // a = 10;
// // console.log("a is", a);
// // var a;

// // var a = 10;
// // var a = "ABC";

// // console.log("a is", a);

// var i = "ABC";
// console.log("Before, i is", i);

// // function test() {
// //     for (var i = 0; i < 5; i++) {
// //         console.log("Inside, i is", i);
// //     }
// // }

// // test();

// // IIFE
// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside, i is", i);
//     }
// })();

// console.log("After, i is", i);

// 1. Fn Declaration Syntax

// function hello1() {
//     console.log("Hello from JS World!");
// }

// hello1();

// // 2. Fn Expression
// var hello2 = function () {
//     console.log("Hello from JS World!");
// }

// hello2();

// // 3. Fn Constructor
// var hello3 = new Function('console.log("Hello from JS World!");');
// hello3();

var i = 10;
console.log(i);
console.log(typeof i);

var h = function () {
    console.log("Hello from JS World!");
}
console.log(h);
console.log(typeof h);


