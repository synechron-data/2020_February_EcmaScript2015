var dev1;

(function (d) {
    function Check() {
        console.log("Check from Dev 1 Called");
    }

    d.Check = Check;
})(dev1 = dev1 || {});