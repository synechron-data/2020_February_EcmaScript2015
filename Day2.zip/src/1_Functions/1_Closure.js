// var count = 0;

// function next() {
//     return count += 1;
// }

// console.log(next());
// count = "ABC";
// console.log(next());
// console.log(next());
// console.log(next());

// -------------------------------
// function next() {
//     var count = 0;
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// console.log(next());
// console.log(next());

// ------------------------------

// var next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// console.log(next());
// console.log(next());
// console.log(next());
// console.log(next());

// ---------------------------------

// var counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.prev());
// console.log(counter.next());
// console.log(counter.prev());

// -------------------------------------

function getCounter(interval) {
    var count = 0;
    var by = interval;

    return {
        next: function () {
            return count += by;
        },
        prev: function () {
            return count -= by;
        }
    };
}

var cntOne = getCounter(1);
console.log(cntOne.next());
console.log(cntOne.prev());

console.log("\n");
var cntFive = getCounter(5);
console.log(cntFive.next());
console.log(cntFive.prev());