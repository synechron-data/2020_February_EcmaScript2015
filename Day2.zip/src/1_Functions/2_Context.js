// function Test() {
//     console.log(this);
// }

// Test();
// Test.call();
// Test.apply();


// var p1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.display();
// p2.display();

// function display(x, y) {
//     console.log(JSON.stringify(this));
// }

var display = function (x, y) {
    console.log(JSON.stringify(this));
}

// var display = (x, y) => {
//     console.log(JSON.stringify(this));
// }

var p1 = {
    id: 1,
    name: "Manish",
};

var p2 = {
    id: 2,
    name: "Abhijeet"
};

// display();
// display.call(p1, 1, 2);
// display.call(p2);

// display.apply(p1, [1, 2]);
// display.apply(p2);

p1.display = display.bind(p1);
p2.display = display.bind(p2);

p1.display();
p2.display();

// function test() {
//     console.log(this);
// }

// // test();

// setInterval(test, 2000);

// function Person(age) {
//     this.age = age;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person(20);

// // setInterval(p1.growOld, 2000);
// setInterval(p1.growOld.bind(p1), 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// function Person(age) {
//     var self = this;
//     self.age = age;

//     self.growOld = function () {
//         self.age += 1;
//     }
// }

// function Person(age) {
//     this.age = age;

//     this.growOld = () => {
//         this.age += 1;
//     }
// }

// var p1 = new Person(20);

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// p1.growOld();
// console.log(p1.age);

// p1.growOld();
// console.log(p1.age);

// p1.growOld();
// console.log(p1.age);

// p1.growOld();
// console.log(p1.age);
