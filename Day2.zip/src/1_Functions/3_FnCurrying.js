// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// const mGreet = greetings.bind(undefined, "Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

var usdToInr = Converter.bind(undefined, ' INR', 70, 0);
console.log(usdToInr(100));
console.log(usdToInr(120));
console.log(usdToInr(600));
console.log(usdToInr(940));
