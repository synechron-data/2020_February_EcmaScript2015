import '../public/favicon.ico';

// import './1_Functions/1_Closure';
// import './1_Functions/2_Context';
// import './1_Functions/3_FnCurrying';

// import './2_Types/1_ObjectCreation';
// import './2_Types/2_ObjectType';
// import './2_Types/3_ObjectMethods';
// import './2_Types/4_CustomTypes';
// import './2_Types/5_UsingPrototype';
// import './2_Types/6_Counter';
// import './2_Types/7_ES6_Class';
// import './2_Types/8_ES5_Properties';
// import './2_Types/9_ES6_Properties';
// import './2_Types/10_ES5_Inheritance';
// import './2_Types/11_ES6_Inheritance';

// import './3_Collections/1_Arrays';
// import './3_Collections/2_Map';
// import './3_Collections/3_Set';
// import './3_Collections/4_CustomCollection';

// import './4_Promise/1_CustomPromise';
import './4_Promise/2_APICalls';










