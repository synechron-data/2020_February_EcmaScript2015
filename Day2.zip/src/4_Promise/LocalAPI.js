const apiClient = {
    getAllPosts: function (successCB, errorCB) {
        fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
            var result = response.json();
            result.then(data => {
                successCB(data);
            }).catch(err => {
                errorCB("JSON Parse Error");
            })
        }, (err) => {
            errorCB("Communication Error");
        });
    },

    getAllPostsUsingPromise: function () {
        var promise = new Promise((resolve, reject) => {
            fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
                var result = response.json();
                result.then(data => {
                    resolve(data);
                }).catch(err => {
                    reject("JSON Parse Error");
                })
            }, (err) => {
                reject("Communication Error");
            });
        });
        return promise;
    }
}

export default apiClient;