import apiClient from "./LocalAPI"

document.getElementById("btnJS").addEventListener("click", function () {
    // apiClient.getAllPosts((data)=>{
    //     console.log(data);
    // }, (eMsg)=>{
    //     console.error(eMsg);
    // });

    apiClient.getAllPostsUsingPromise().then((data)=>{
        console.log(data);
    }, (eMsg)=>{
        console.error(eMsg);
    });
})