class Vehicle {
    constructor(m = "Honda") {
        this._make = m;
    }

    start() {
        return `${this._make}, engine started`
    }
}

class FourWheeler extends Vehicle {
    constructor(mk = "Honda", md = "Civic") {
        super(mk);
        this._model = md;
    }

    move() {
        return `Moving like a car`;
    }

    start(){
        return `${super.start()}, model is ${this._model}`;
    }
}

var v = new FourWheeler("Ford", "Mustang");
console.log(v.start());
console.log(v.move());