const Person = (function () {
    function Person(name) {
        this._name = name;
    }

    Object.defineProperty(Person.prototype, "Name", {
        set: function (name) {
            if (!name) {
                throw Error("Name is required.");
            }
    
            this._name = name;
        },
        get: function () {
            return this._name;
        }
    });

    return Person;
})();

var p1 = new Person("Manish");
console.log(p1.Name);
p1.Name = "Abhijeet";
console.log(p1.Name);
