// const Counter = (function () {
//     function Counter(interval) {
//         this._count = 0;
//         this._by = interval;
//     }

//     Counter.prototype.next = function () {
//         return this._count += this._by;
//     }

//     Counter.prototype.prev = function () {
//         return this._count -= this._by;
//     }

//     return Counter;
// })();

class Counter {
    constructor(interval) {
        this._count = 0;
        this._by = interval;
    }

    next() {
        return this._count += this._by;
    }

    prev() {
        return this._count -= this._by;
    }
}

var cntOne = new Counter(1);
console.log(cntOne.next());
console.log(cntOne.prev());

console.log("\n");
var cntFive = new Counter(5);
console.log(cntFive.next());
console.log(cntFive.prev());