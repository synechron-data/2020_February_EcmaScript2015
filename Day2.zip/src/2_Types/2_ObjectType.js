var toy1 = new Object();
var toy2 = new Object();
// console.log(toy1);
// console.log(toy1.toString());

toy1.id = 1;
Object.prototype.color = "red";
console.log(toy1.color);
// console.log(toy1.color);
toy2.color = "blue";
console.log(toy2.color);

console.log(toy1);
console.log(toy2);