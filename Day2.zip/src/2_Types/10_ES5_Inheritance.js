var Vehicle = (function () {
    function Vehicle(m) {
        this._make = m || "Honda";
    }

    Vehicle.prototype.start = function () {
        return `${this._make}, engine started`
    }

    return Vehicle;
})();

var FourWheeler = (function () {
    function FourWheeler(mk) { 
        Vehicle.call(this, mk);
    }

    FourWheeler.prototype = Object.create(Vehicle.prototype);
    FourWheeler.prototype.constructor = FourWheeler;

    FourWheeler.prototype.move = function () {
        return `Moving like a car`;
    }

    FourWheeler.prototype.start = function(){
        return `Fourwheeler Implementation`;
    }

    return FourWheeler;
})();

var v = new FourWheeler("Ford");
console.log(v.start());
console.log(v.move());
// console.log(FourWheeler.prototype.constructor);