class Person {
    constructor(name) {
        this._name = name;
        this._age = 0;
    }

    get Name() {
        return this._name;
    }

    get Age() {
        return this._age;
    }

    set Age(value) {
        this._age = value;
    }

    set Name(name) {
        if (!name) {
            throw Error("Name is required.");
        }

        this._name = name;
    }
}

var p1 = new Person("Manish");
console.log(p1.Name);
p1.Name = "Abhijeet";
p1.Age = 34;
console.log(p1.Name);
console.log(p1.Age);