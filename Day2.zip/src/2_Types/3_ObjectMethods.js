// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// const newSource1 = Object.assign({}, source);
// const newSource2 = Object.create(source);

// console.log(source);
// console.log(newSource1);
// console.log(newSource2);

// -----------------------------------------
// let source = { id: 1, name: "Manish" };

// Object.preventExtensions(source);

// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// }

// Object.freeze(source);
// if (!Object.isFrozen()) {
//     source.id = 100;
//     console.log(source);
// }

// Object.seal(source);

// if (!Object.isSealed(source)) {
//     source.city = "Pune";
//     delete source.id;
//     console.log(source);
// }

// -------------------------

// function Test(){

// }

// console.log(Test.prototype);
// var o = new Test();
// Object.setPrototypeOf(o, new Object());
// console.log(o);

// var o1 = new Test();
// console.log(o1);

// -----------------------------------------
let source = { id: 1, name: "Manish" };
let newSource = Object.create(source);
newSource.city = "Pune";

// source["id"] = "Test";
// console.log(source);

console.log(newSource);

for (const key in newSource) {
    console.log(key);
    // console.log(key + "\t" + source[key]);
}

console.log("\n");

Object.keys(newSource).forEach((key)=>{
    console.log(key);
});