var set = new Set();

// console.log(set);
// console.log(typeof set);

// set.add(1);
// set.add(1);
// set.add(2);
// set.add(3);
// set.add(3);
// set.add(4);
// set.add(5);
// set.add(5);

// console.log(set);

var obj1 = { id: 1 };
var obj2 = { id: 1 };

// set.add(obj);
// set.add(obj);

set.add(obj1);
set.add(obj2);

console.log(set);
