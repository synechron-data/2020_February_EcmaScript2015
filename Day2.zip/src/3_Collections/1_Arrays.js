// // var employees = new Array();
// // var employees = [];
// var employees = new Array(2);

// employees[0] = "Manish";
// employees[1] = "Abhijeet";
// employees[5] = "Ramakant";

// console.log(employees);
// console.log(employees.length);

// // console.log(typeof employees);

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i} - ${employees[i]}`);    
// }

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i} - ${employees[i].name}`);
// }

// for (const key in employees) {
//     console.log(`${key} - ${employees[key].name}`);
// }

// employees.forEach((item, index, arr) => {
//     console.log(`${index} - ${item.name}`);
// })

// for (const item of employees) {
//     console.log(`${item.id}, ${item.name}`);
// }

// console.log(employees.entries());

// for (const [index, item] of employees.entries()) {
//     console.log(`${index}, ${item.name}`);;
// }

// -----------------------------

// var numbers = new Array(2);
// var numbers = new Array("Manish");
// var numbers = [2];

// var numbers = Array.of(2);
// var numbers = Array.from("Manish");
// var numbers = [..."Manish"];

// console.log(numbers);