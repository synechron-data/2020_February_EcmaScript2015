class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }
    // }

    // [Symbol.iterator]() {
    //     const self = this;
    //     let i = 0;

    //     return {
    //         next: function () {
    //             let v, d = true;

    //             if (self._dataArray[i] !== undefined) {
    //                 v = self._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             }
    //         }
    //     };
    // }
}

var nQ = new Queue();
nQ.push(10);
nQ.push(20);
nQ.push(30);

// console.log(nQ.pop());
// console.log(nQ.pop());
// console.log(nQ.pop());

// for (const item of nQ) {
//     console.log(item);
// }

function* idGenerator(n) {
    let index = 0;
    while (index < n) {
        yield index++;
    }
}

console.log([...idGenerator(2)])
console.log([...idGenerator(5)])
console.log([...idGenerator(10)])